"""
Base classes for mini_scikit_learn.
"""
