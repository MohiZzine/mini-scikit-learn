class BaseEstimator:
    """
    Base class for all estimators.
    """
    pass
