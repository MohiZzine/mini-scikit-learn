from .base_predictor import BasePredictor

class BaseRegressor(BasePredictor):
    """
    Base class for all regressors.
    """
    pass
