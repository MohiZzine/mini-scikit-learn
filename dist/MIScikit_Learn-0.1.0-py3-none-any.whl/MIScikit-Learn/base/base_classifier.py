from .base_predictor import BasePredictor

class BaseClassifier(BasePredictor):
    """
    Base class for all classifiers.
    """
    pass
