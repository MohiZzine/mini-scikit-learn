from .base_transformer import BaseTransformer

class Normalizer(BaseTransformer):
    """
    Example normalizer class.
    """
    def fit(self, data):
        # Implement fitting logic
        pass
    
    def transform(self, data):
        # Implement transform logic
        pass
    

    